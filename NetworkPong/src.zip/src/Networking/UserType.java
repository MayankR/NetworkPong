package Networking;

public enum UserType {
	START, JOIN
}
