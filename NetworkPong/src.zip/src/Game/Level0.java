package Game;

import java.awt.Graphics;
import java.awt.Image;

public class Level0 implements Level{

	public void display(Graphics g, Image i1[])
	{
	}
	
	public void reflect(Ball ball)
	{
	}
	

}
